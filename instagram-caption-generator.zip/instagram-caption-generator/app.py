import os
import base64
import json
from flask import Flask, request, jsonify, render_template
from groq import Groq
from dotenv import load_dotenv
from pathlib import Path

load_dotenv()

app = Flask(__name__)

# ── Groq client ───────────────────────────────────────────────────────
client = Groq(api_key=os.getenv("GROQ_API_KEY", ""))

VISION_MODEL = "meta-llama/llama-4-scout-17b-16e-instruct"

# ── Caption styles ────────────────────────────────────────────────────
STYLES = {
    "fun": {
        "label": "Fun & Playful",
        "emoji": "🎉",
        "prompt": (
            "You are a fun Instagram content creator. Generate 3 different "
            "Instagram captions for this image. Each caption should be fun, "
            "energetic, and relatable. Include relevant emojis throughout and "
            "end with 10-15 trending hashtags. Make them feel authentic, not corporate. "
            "Format: Caption 1: [caption]\n\nCaption 2: [caption]\n\nCaption 3: [caption]"
        ),
    },
    "aesthetic": {
        "label": "Aesthetic & Moody",
        "emoji": "🌙",
        "prompt": (
            "You are an aesthetic Instagram influencer. Generate 3 moody, "
            "poetic Instagram captions for this image. Use evocative language, "
            "short sentences, and a dreamy vibe. Include subtle emojis and "
            "10-15 aesthetic hashtags. "
            "Format: Caption 1: [caption]\n\nCaption 2: [caption]\n\nCaption 3: [caption]"
        ),
    },
    "funny": {
        "label": "Funny & Witty",
        "emoji": "😂",
        "prompt": (
            "You are a hilarious Instagram comedian. Generate 3 funny, witty "
            "Instagram captions for this image. Use humor, sarcasm, or clever "
            "wordplay. Include funny emojis and 10-15 relevant hashtags. "
            "Format: Caption 1: [caption]\n\nCaption 2: [caption]\n\nCaption 3: [caption]"
        ),
    },
    "inspirational": {
        "label": "Inspirational",
        "emoji": "✨",
        "prompt": (
            "You are an inspirational Instagram coach. Generate 3 motivational "
            "Instagram captions for this image. Use uplifting, powerful words "
            "that inspire action. Include positive emojis and 10-15 motivational hashtags. "
            "Format: Caption 1: [caption]\n\nCaption 2: [caption]\n\nCaption 3: [caption]"
        ),
    },
    "travel": {
        "label": "Travel Vibes",
        "emoji": "✈️",
        "prompt": (
            "You are a travel Instagram influencer. Generate 3 wanderlust-inducing "
            "Instagram captions for this image. Mention adventure, exploration, "
            "and the beauty of travel. Include travel emojis and 10-15 travel hashtags. "
            "Format: Caption 1: [caption]\n\nCaption 2: [caption]\n\nCaption 3: [caption]"
        ),
    },
    "food": {
        "label": "Food & Foodie",
        "emoji": "🍕",
        "prompt": (
            "You are a foodie Instagram influencer. Generate 3 mouth-watering "
            "Instagram captions for this image. Make people hungry and excited. "
            "Include food emojis and 10-15 food hashtags. "
            "Format: Caption 1: [caption]\n\nCaption 2: [caption]\n\nCaption 3: [caption]"
        ),
    },
}


# ── Routes ─────────────────────────────────────────────────────────────
@app.route("/")
def index():
    return render_template("index.html", styles=STYLES)


@app.route("/generate", methods=["POST"])
def generate():
    if "image" not in request.files:
        return jsonify({"error": "No image uploaded"}), 400

    image_file = request.files["image"]
    style = request.form.get("style", "fun")

    if image_file.filename == "":
        return jsonify({"error": "No image selected"}), 400

    # Validate file type
    allowed = {".jpg", ".jpeg", ".png", ".gif", ".webp"}
    ext = Path(image_file.filename).suffix.lower()
    if ext not in allowed:
        return jsonify({"error": f"Unsupported file type: {ext}"}), 400

    # Encode image to base64
    image_data = image_file.read()
    if len(image_data) > 10 * 1024 * 1024:
        return jsonify({"error": "Image too large (max 10MB)"}), 400

    mime_map = {
        ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
        ".png": "image/png", ".gif": "image/gif", ".webp": "image/webp",
    }
    mime = mime_map.get(ext, "image/jpeg")
    b64 = base64.b64encode(image_data).decode("utf-8")

    style_info = STYLES.get(style, STYLES["fun"])
    system_prompt = style_info["prompt"]

    try:
        response = client.chat.completions.create(
            model=VISION_MODEL,
            messages=[
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "text",
                            "text": system_prompt,
                        },
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:{mime};base64,{b64}"
                            },
                        },
                    ],
                }
            ],
            max_tokens=1500,
            temperature=0.8,
        )

        raw = response.choices[0].message.content or ""
        captions = parse_captions(raw)

        return jsonify({
            "success": True,
            "captions": captions,
            "style": style_info["label"],
            "raw": raw,
        })

    except Exception as e:
        return jsonify({"error": f"AI error: {str(e)[:200]}"}), 500


def parse_captions(text: str) -> list[str]:
    """Parse the 3 captions from the AI response."""
    captions = []
    import re
    # Try to split by Caption 1:, Caption 2:, Caption 3:
    parts = re.split(r"Caption\s*\d+\s*:", text, flags=re.IGNORECASE)
    parts = [p.strip() for p in parts if p.strip()]
    if len(parts) >= 3:
        return parts[:3]
    # Fallback: split by double newline
    parts = [p.strip() for p in text.split("\n\n") if p.strip()]
    if len(parts) >= 2:
        return parts[:3]
    # Last resort: return whole text as one caption
    return [text.strip()]


# ── Health check for Render ────────────────────────────────────────────
@app.route("/health")
def health():
    return jsonify({"status": "ok"})


if __name__ == "__main__":
    port = int(os.getenv("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=False)
